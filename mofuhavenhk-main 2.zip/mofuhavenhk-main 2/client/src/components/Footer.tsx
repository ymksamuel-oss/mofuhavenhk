import { Separator } from "@/components/ui/separator";
import { Mail, MessageCircle } from "lucide-react";
import {
  AlipayHkLogo,
  ApplePayLogo,
  MastercardLogo,
  VisaLogo,
  WeChatPayLogo,
} from "@/components/icons/PaymentIcons";

/**
 * Footer Component
 * Design: Japanese Healing Aesthetic
 * - Warm background
 * - Clear information hierarchy
 * - Contact methods highlighted
 * - Enhanced brand identity
 */
export default function Footer() {
  return (
    <footer className="bg-gradient-to-b from-secondary/10 to-primary/5 border-t border-border mt-16 md:mt-24">
      <div className="container py-12 md:py-16">
        {/* Footer Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-12 mb-12">
          {/* Brand Section - Enhanced Wordmark */}
          <div className="md:col-span-1">
            <a href="/" className="inline-block group mb-4">
              <div className="flex items-center gap-2 group-hover:scale-105 transition-transform">
                <img
                  src="/manus-storage/mofu-haven-logo_75fb6778.png"
                  alt="Mofu Haven"
                  className="w-8 h-8"
                />
                <div>
                  <h3 className="font-bold text-foreground">毛毛港</h3>
                  <p className="text-xs text-primary font-semibold">Mofu Haven</p>
                </div>
              </div>
            </a>
            <p className="text-sm text-foreground/70 leading-relaxed">
              專營日本優質寵物糧食及用品，為愛寵提供最安心的選擇。提供 3-5 日發貨與 7 日退換貨保障。
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">快捷連結</h4>
            <ul className="space-y-2">
              {[
                { label: "全部商品", href: "/menu" },
                { label: "關於我們", href: "/contact" },
                { label: "常見問題 (FAQ)", href: "/faq" }
              ].map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link.href}
                    className="text-sm text-foreground/70 hover:text-primary transition-colors duration-200 relative group/link inline-block py-0.5"
                  >
                    {link.label}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover/link:w-full transition-all duration-300" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">顧客服務</h4>
            <ul className="space-y-2">
              {[
                { label: "運送與發貨政策", href: "/faq" },
                { label: "退換貨政策", href: "/faq" },
                { label: "私隱政策與服務條款", href: "/privacy" },
                { label: "聯絡我們", href: "/contact" }
              ].map((link, idx) => (
                <li key={idx}>
                  <a
                    href={link.href}
                    className="text-sm text-foreground/70 hover:text-primary transition-colors duration-200 relative group/link inline-block py-0.5"
                  >
                    {link.label}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover/link:w-full transition-all duration-300" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact - Highlighted */}
          <div>
            <h4 className="font-semibold text-foreground mb-4">聯絡我們</h4>
            <div className="space-y-3">
              <a
                href="https://wa.me/85298646585?text=Mofu%20Haven%20%E2%80%94%20WhatsApp%20%E5%B0%88%E4%BA%BA%E6%9F%A5%E8%A9%A2"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-sm text-foreground/70 hover:text-primary transition-colors duration-200 group/contact"
              >
                <MessageCircle className="w-4 h-4 text-[#25D366] group-hover/contact:scale-110 transition-transform" />
                WhatsApp 專人查詢
              </a>
              <a
                href="mailto:hello@mofuhavenhk.com"
                className="flex items-center gap-2 text-sm text-foreground/70 hover:text-primary transition-colors duration-200 group/contact"
              >
                <Mail className="w-4 h-4 text-primary group-hover/contact:scale-110 transition-transform" />
                hello@mofuhavenhk.com
              </a>
              <p className="text-xs text-muted-foreground pt-2 border-t border-border/50">
                <span className="font-semibold text-foreground/70">服務時間</span><br />
                週一至週五 10:00 – 19:00
              </p>
            </div>
          </div>
        </div>

        {/* Separator */}
        <Separator className="my-8" />

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Copyright */}
          <p className="text-sm text-muted-foreground">
            © 2026 Mofu Haven. All Rights Reserved. 3-5日發貨・7日退換貨保障.
          </p>

          {/* Payment Methods */}
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-4">
            <span className="text-xs text-muted-foreground font-medium">接受付款方式：</span>
            <div className="flex flex-wrap items-center justify-center gap-3 sm:justify-end">
              <span className="flex h-7 min-w-[4rem] items-center justify-center">
                <img
                  src="/payment/wechat-pay-logo.png"
                  alt="WeChat Pay"
                  className="h-5 w-auto max-w-[4rem] object-contain"
                />
              </span>
              <span className="flex h-7 min-w-[4rem] items-center justify-center">
                <img
                  src="/payment/alipayhk-logo.svg"
                  alt="AlipayHK"
                  className="h-5 w-auto max-w-[4rem] object-contain"
                />
              </span>
              <span className="flex h-7 min-w-[4rem] items-center justify-center">
                <img
                  src="/payment/visa-brandmark-blue.png"
                  alt="Visa"
                  className="h-5 w-auto max-w-[4rem] object-contain"
                />
              </span>
              <span className="flex h-7 min-w-[4rem] items-center justify-center">
                <img
                  src="/payment/mastercard-symbol.png"
                  alt="Mastercard"
                  className="h-5 w-auto max-w-[4rem] object-contain"
                />
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
