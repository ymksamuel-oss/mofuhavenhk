"use client";

import Image from "next/image";
import Link from "next/link";
import { Zen_Maru_Gothic } from "next/font/google";
import { categoryHref } from "@/lib/categories";
import { useI18n } from "@/lib/i18n/I18nProvider";
import type { TranslationKey } from "@/lib/i18n/translations";

const zenMaru = Zen_Maru_Gothic({
  subsets: ["latin"],
  weight: ["400", "500", "700"],
});

type Chapter = {
  titleKey: TranslationKey;
  bodyKey: TranslationKey;
  image: string;
  imageAltKey: TranslationKey;
};

const CHAPTERS: Chapter[] = [
  {
    titleKey: "aboutCatChapter1Title",
    bodyKey: "aboutCatChapter1Body",
    image:
      "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=800&auto=format&fit=crop",
    imageAltKey: "aboutCatChapter1Alt",
  },
  {
    titleKey: "aboutCatChapter2Title",
    bodyKey: "aboutCatChapter2Body",
    image:
      "https://images.unsplash.com/photo-1548802673-380ab8ebc7b7?w=800&auto=format&fit=crop",
    imageAltKey: "aboutCatChapter2Alt",
  },
  {
    titleKey: "aboutCatChapter3Title",
    bodyKey: "aboutCatChapter3Body",
    image:
      "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?w=800&auto=format&fit=crop",
    imageAltKey: "aboutCatChapter3Alt",
  },
  {
    titleKey: "aboutCatChapter4Title",
    bodyKey: "aboutCatChapter4Body",
    image:
      "https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=800&auto=format&fit=crop",
    imageAltKey: "aboutCatChapter4Alt",
  },
  {
    titleKey: "aboutCatChapter5Title",
    bodyKey: "aboutCatChapter5Body",
    image:
      "https://images.unsplash.com/photo-1519052537078-e6302a4968d4?w=800&auto=format&fit=crop",
    imageAltKey: "aboutCatChapter5Alt",
  },
];

/**
 * Japanese-style picture-book guide for new cat parents.
 */
export function AboutCatBook() {
  const { t } = useI18n();

  return (
    <div
      className={`${zenMaru.className} min-h-[70vh] bg-[#FBF9F6] text-[#2B2623]`}
    >
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
        <p className="mb-6">
          <Link
            href="/menu"
            className="text-sm font-medium text-[#2B2623]/70 transition hover:text-[#2B2623]"
          >
            ← {t("aboutCatBackToCatalog")}
          </Link>
        </p>

        <header className="mb-12 max-w-2xl animate-[fadeUp_0.55s_ease_both] sm:mb-16">
          <p className="text-sm font-medium tracking-[0.08em] text-[#2B2623]/65">
            {t("aboutCatEyebrow")}
          </p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight sm:text-4xl">
            {t("aboutCatTitle")}
          </h1>
          <p className="mt-3 text-base leading-relaxed text-[#2B2623]/80 sm:text-lg">
            {t("aboutCatSubtitle")}
          </p>
        </header>

        <div className="space-y-12 sm:space-y-16">
          {CHAPTERS.map((chapter, index) => {
            const imageLeft = index % 2 === 0;
            return (
              <section
                key={chapter.titleKey}
                className={`grid items-center gap-6 sm:gap-10 md:grid-cols-2 ${
                  imageLeft ? "" : "md:[&>*:first-child]:order-2"
                }`}
                style={{
                  animation: `fadeUp 0.6s ease both`,
                  animationDelay: `${0.08 * (index + 1)}s`,
                }}
              >
                <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border border-[#2B2623]/12 bg-white shadow-[0_18px_36px_-22px_rgba(74,59,50,0.45)]">
                  {chapter.image.startsWith("http") ? (
                    // External Unsplash URLs — native img avoids next.config remotePatterns.
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={chapter.image}
                      alt={t(chapter.imageAltKey)}
                      className="absolute inset-0 h-full w-full object-cover"
                    />
                  ) : (
                    <Image
                      src={chapter.image}
                      alt={t(chapter.imageAltKey)}
                      fill
                      sizes="(min-width: 768px) 40vw, 90vw"
                      className="object-cover"
                    />
                  )}
                </div>
                <div className="space-y-3">
                  <p className="text-xs font-semibold tracking-[0.14em] text-[#2B2623]/55">
                    {String(index + 1).padStart(2, "0")}
                  </p>
                  <h2 className="text-2xl font-bold tracking-tight sm:text-[1.7rem]">
                    {t(chapter.titleKey)}
                  </h2>
                  <p className="text-[0.98rem] leading-relaxed text-[#2B2623]/85 sm:text-base">
                    {t(chapter.bodyKey)}
                  </p>
                </div>
              </section>
            );
          })}
        </div>

        <div
          className="mt-14 flex justify-center sm:mt-20"
          style={{ animation: "fadeUp 0.6s ease both", animationDelay: "0.55s" }}
        >
          <Link
            href={categoryHref("cats")}
            className="inline-flex min-h-12 items-center justify-center rounded-2xl border border-[#2B2623]/15 bg-[#2B2623] px-6 py-3 text-sm font-semibold text-[#FBF9F6] shadow-[0_14px_28px_-16px_rgba(74,59,50,0.55)] transition hover:-translate-y-0.5 hover:bg-[#3a2e27] hover:shadow-[0_18px_32px_-14px_rgba(74,59,50,0.6)] active:translate-y-0"
          >
            {t("aboutCatShopCta")}
          </Link>
        </div>
      </div>
    </div>
  );
}
